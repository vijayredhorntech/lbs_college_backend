{{--<img src="{{ asset('assets/images/logo.png') }}" alt="{{ config('info.app_name') }}" class="h-16 w-auto">--}}
<span class="font-bold text-white text-xl">
    LBS Degree College
</span>
