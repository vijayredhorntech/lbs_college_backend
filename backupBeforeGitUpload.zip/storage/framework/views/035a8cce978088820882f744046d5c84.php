<div class="px-4 py-6 w-full">
        <div class="relative bg-primaryDark px-4 py-2 rounded-sm  border-[1px] border-primaryDark flex justify-between items-center">
                <span class="text-xl text-white/90 font-bold mb-1">
                  Education Details
                </span>

            <span  wire:click="addForm" class=" w-max bg-white/90 rounded-[3px] text-primaryDark px-4 py-1 font-semibold text-sm border-[1px] border-white/90 hover:bg-white transition ease-in duration-2000">
                Add More
            </span>
        </div>
        <div class="p-4 bg-white">
            <form wire:submit.prevent="submitForm" class="">
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $form; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="grid lg:grid-cols-4 md:grid-cols-3 sm:grid-cols-2 grid-cols-1 gap-2">

                        <div class="w-full flex flex-col gap-1">
                            <label for="examination_name_<?php echo e($index); ?>" class="font-semibold text-sm text-black">Examination Name</label>
                            <input type="text" placeholder="Examination Name" id="examination_name_<?php echo e($index); ?>" wire:model="form.<?php echo e($index); ?>.examination_name" class="px-4 py-2.5 text-primaryDark placeholder-primaryDark/60 rounded-[3px] border-[1px] border-primaryDark/60 focus:ring-0 focus:outline-none focus:border-primaryDark hover:border-primaryDark">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['form.'.$index.'.examination_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="w-full flex flex-col gap-1">
                            <label for="result_<?php echo e($index); ?>" class="font-semibold text-sm text-black">Result</label>
                            <input type="text" placeholder="Result" id="result_<?php echo e($index); ?>" wire:model="form.<?php echo e($index); ?>.result" class="px-4 py-2.5 text-primaryDark placeholder-primaryDark/60 rounded-[3px] border-[1px] border-primaryDark/60 focus:ring-0 focus:outline-none focus:border-primaryDark hover:border-primaryDark">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['form.'.$index.'.result'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="w-full flex flex-col gap-1">
                            <label for="year_month_of_passing_<?php echo e($index); ?>" class="font-semibold text-sm text-black">Year/Month of Passing</label>
                            <input type="text" placeholder="Year of passing" id="year_month_of_passing_<?php echo e($index); ?>" wire:model="form.<?php echo e($index); ?>.year_month_of_passing" class="px-4 py-2.5 text-primaryDark placeholder-primaryDark/60 rounded-[3px] border-[1px] border-primaryDark/60 focus:ring-0 focus:outline-none focus:border-primaryDark hover:border-primaryDark">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['form.'.$index.'.year_month_of_passing'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="w-full flex flex-col gap-1">
                            <label for="roll_number_<?php echo e($index); ?>" class="font-semibold text-sm text-black">Roll Number</label>
                            <input type="text" placeholder="Roll No" id="roll_number_<?php echo e($index); ?>" wire:model="form.<?php echo e($index); ?>.roll_number" class="px-4 py-2.5 text-primaryDark placeholder-primaryDark/60 rounded-[3px] border-[1px] border-primaryDark/60 focus:ring-0 focus:outline-none focus:border-primaryDark hover:border-primaryDark">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['form.'.$index.'.roll_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="w-full flex flex-col gap-1">
                            <label for="board_university_<?php echo e($index); ?>" class="font-semibold text-sm text-black">Board/ University</label>
                            <input type="text" placeholder="Board/ University" id="board_university_<?php echo e($index); ?>" wire:model="form.<?php echo e($index); ?>.board_university" class="px-4 py-2.5 text-primaryDark placeholder-primaryDark/60 rounded-[3px] border-[1px] border-primaryDark/60 focus:ring-0 focus:outline-none focus:border-primaryDark hover:border-primaryDark">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['form.'.$index.'.board_university'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="w-full flex flex-col gap-1">
                            <label for="name_of_institution_<?php echo e($index); ?>" class="font-semibold text-sm text-black">Name of Institute</label>
                            <input type="text" placeholder="Name of institute" id="name_of_institution_<?php echo e($index); ?>" wire:model="form.<?php echo e($index); ?>.name_of_institution" class="px-4 py-2.5 text-primaryDark placeholder-primaryDark/60 rounded-[3px] border-[1px] border-primaryDark/60 focus:ring-0 focus:outline-none focus:border-primaryDark hover:border-primaryDark">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['form.'.$index.'.name_of_institution'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="w-full flex flex-col gap-1">
                            <label for="obtained_total_marks_<?php echo e($index); ?>" class="font-semibold text-sm text-black">Total Marks Obtained</label>
                            <input type="text" placeholder="Total marks obtained" id="obtained_total_marks_<?php echo e($index); ?>" wire:model="form.<?php echo e($index); ?>.obtained_total_marks" class="px-4 py-2.5 text-primaryDark placeholder-primaryDark/60 rounded-[3px] border-[1px] border-primaryDark/60 focus:ring-0 focus:outline-none focus:border-primaryDark hover:border-primaryDark">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['form.'.$index.'.obtained_total_marks'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="w-full flex flex-col gap-1">
                            <label for="cgpa_<?php echo e($index); ?>" class="font-semibold text-sm text-black">CGPA</label>
                            <input type="text" placeholder="CGPA" id="cgpa_<?php echo e($index); ?>" wire:model="form.<?php echo e($index); ?>.cgpa" class="px-4 py-2.5 text-primaryDark placeholder-primaryDark/60 rounded-[3px] border-[1px] border-primaryDark/60 focus:ring-0 focus:outline-none focus:border-primaryDark hover:border-primaryDark">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['form.'.$index.'.cgpa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="w-full flex flex-col gap-1">
                            <label for="percentage_<?php echo e($index); ?>" class="font-semibold text-sm text-black">Percentage</label>
                            <input type="text" placeholder="Percentage" id="percentage_<?php echo e($index); ?>" wire:model="form.<?php echo e($index); ?>.percentage" class="px-4 py-2.5 text-primaryDark placeholder-primaryDark/60 rounded-[3px] border-[1px] border-primaryDark/60 focus:ring-0 focus:outline-none focus:border-primaryDark hover:border-primaryDark">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['form.'.$index.'.percentage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="w-full flex flex-col gap-1">
                            <label for="subjects_<?php echo e($index); ?>" class="font-semibold text-sm text-black">Subjects</label>
                            <input type="text" placeholder="Subjects" id="subjects_<?php echo e($index); ?>" wire:model="form.<?php echo e($index); ?>.subjects" class="px-4 py-2.5 text-primaryDark placeholder-primaryDark/60 rounded-[3px] border-[1px] border-primaryDark/60 focus:ring-0 focus:outline-none focus:border-primaryDark hover:border-primaryDark">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['form.'.$index.'.subjects'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="w-full flex items-end gap-1 ">
                            <span
                                wire:click="removeForm(<?php echo e($index); ?>)"
                                class="w-max bg-red/90 rounded-[3px] text-white px-4 py-1 font-semibold text-sm border-[1px] border-red/90 hover:bg-red transition ease-in duration-2000"
                            >Remove</span>
                        </div>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                <div class="mt-4 w-full flex justify-end">
                    <button type="submit" class="w-max bg-primaryDark/80 rounded-[3px] text-white px-4 py-1.5 font-semibold text-md border-[1px] border-primaryDark hover:bg-primaryDark transition ease-in duration-2000">
                        Save
                    </button>
                </div>
            </form>

        </div>
    </div>










<?php /**PATH /home/vinumuum/lbsattendance.himsoft.online/resources/views/livewire/student-education.blade.php ENDPATH**/ ?>