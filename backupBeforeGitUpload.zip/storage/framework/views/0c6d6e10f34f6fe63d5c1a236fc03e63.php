<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>application_form_<?php echo e($student->full_name); ?>_<?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400..700&display=swap" rel="stylesheet" />
    <script src="https://kit.fontawesome.com/641cc4ef4e.js" crossorigin="anonymous"></script>

    <script >window.Wireui = {hook(hook, callback) {window.addEventListener(`wireui:${hook}`, () => callback())},dispatchHook(hook) {window.dispatchEvent(new Event(`wireui:${hook}`))}}</script>
<script src="https://college.test/wireui/assets/scripts?id=eac37e3099acafcb5036e20dd54a70e9" defer ></script>
    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    <!-- Styles -->
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>


    <style>
        @media print {
            /* set margins*/
            @page {
                margin: 10px;
            }
            .page-break {
                page-break-before: always;
            }
        }
    </style>

</head>
<body>

<?php if (isset($component)) { $__componentOriginala8bd0c71046a48658fc8e3324f64b484 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8bd0c71046a48658fc8e3324f64b484 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.student-details','data' => ['student' => $student]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('student-details'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['student' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($student)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8bd0c71046a48658fc8e3324f64b484)): ?>
<?php $attributes = $__attributesOriginala8bd0c71046a48658fc8e3324f64b484; ?>
<?php unset($__attributesOriginala8bd0c71046a48658fc8e3324f64b484); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8bd0c71046a48658fc8e3324f64b484)): ?>
<?php $component = $__componentOriginala8bd0c71046a48658fc8e3324f64b484; ?>
<?php unset($__componentOriginala8bd0c71046a48658fc8e3324f64b484); ?>
<?php endif; ?>
<?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

<script>
    window.print();
</script>
</body>
</html>
<?php /**PATH D:\laravel\college\resources\views/admin/student/profile-print.blade.php ENDPATH**/ ?>