<div class="relative bg-primaryDark px-4 py-2 rounded-sm overflow-hidden border-[1px] border-primaryDark">
    <div class="relative">
        <h1 class="text-2xl md:text-3xl text-white/90 font-bold mb-1">
            Hello, <?php echo e(Auth::user()->name); ?> 👋</h1>

        <?php if (\Illuminate\Support\Facades\Blade::check('role', 'student')): ?>
        <?php if(!Auth()->user()->student): ?>
            <p class="text-white text-sm">Your profile is incomplete, complete the form below to proceed.</p>
        <?php endif; ?>
        <?php endif; ?>

        <?php if(!Auth()->user()->student?->enrollment->count() && Auth()->user()->student): ?>
            <p class="text-white text-sm">You have not enrolled in any course yet. Choose one of the following
                course to enroll</p>
        <?php endif; ?>
    </div>
</div>

<?php if (\Illuminate\Support\Facades\Blade::check('role', 'student')): ?>
    <?php if(!Auth()->user()->student): ?>
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('student-enrollment-form', []);

$__html = app('livewire')->mount($__name, $__params, 'HxYcvar', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    <?php endif; ?>
<?php endif; ?>


<?php if(!Auth()->user()->student?->enrollment->count() && Auth()->user()->student): ?>
    <div class="grid lg:grid-cols-4 md:grid-cols-3 sm:grid-cols-2 grid-cols-1 border-[1px] border-primaryDark bg-white p-4 gap-4">
        <?php $__currentLoopData = App\Models\CourseSchedule::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class=" flex flex-col bg-gray-100 shadow-md shadow-gray-300 text-center  rounded-[3px]">
                <div class="w-full bg-primaryDark text-white p-2 rounded-t-[3px]">
                      <span class="font-semibold"><?php echo e($schedule->course->name); ?>(<?php echo e($schedule->year); ?> Year) </span>
                </div>
                <div class="border-b-[1px] border-primaryDark p-2">
                    <span class="font-semibold text-primaryDark">Submission Date:</span>
                    <div class="text-black/80"><?php echo e($schedule->submission_from->format('d-m-Y')); ?> to <?php echo e($schedule->submission_till->format('d-m-Y')); ?></div>
                </div>
                <div class="border-b-[1px] border-primaryDark p-2">
                    <span class="font-semibold text-primaryDark">Late Fee From:</span>
                    <div class="text-black/80"><?php echo e($schedule->late_fee_starts_from->format('d-m-Y')); ?></div>
                </div>
                <?php
                    $student = auth()->user()->student;
                ?>

                <div class="p-2 bg-<?php echo e($student->documents()->count() && $student->education()->count()?'green':'red'); ?>/60 rounded-b-[3px] w-full">
                    <?php if($student->documents()->count() && $student->education()->count()): ?>
                        <a href="<?php echo e(route('student-enrollment',[auth()->user()->student, $schedule])); ?>" class="mt-4 w-full bg-primaryDark/80 rounded-[3px] text-white px-4 py-1.5 font-semibold text-md border-[1px] border-primaryDark hover:bg-primaryDark transition ease-in duration-2000">
                            <i class="fa fa-arrow-right"></i> Enroll Now
                        </a>
                    <?php else: ?>
                        <span class="  text-sm text-red font-semibold">Add All the Documents and Education Details to Enroll</span>
                    <?php endif; ?>
                </div>



            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>
<?php /**PATH /home/vinumuum/lbsattendance.himsoft.online/resources/views/components/dashboard/welcome-banner.blade.php ENDPATH**/ ?>