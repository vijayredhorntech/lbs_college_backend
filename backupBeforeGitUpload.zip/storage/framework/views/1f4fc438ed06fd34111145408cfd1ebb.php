<div class="px-4 sm:px-6 lg:px-8 py-8 w-full max-w-9xl mx-auto">
    <div
        class="flex flex-col col-span-full sm:col-span-6 bg-white dark:bg-slate-800 shadow-lg rounded-sm border border-slate-200 dark:border-slate-700">
        <header class="flex justify-between items-center px-5 py-4 border-b border-slate-100 dark:border-slate-700">
            <h2 class="font-semibold text-slate-800 dark:text-slate-100">
                <?php echo e($student->fullName); ?>'s Profile
            </h2>
            <h2>
                <a href="<?php echo e(route('student-profile-print',$student)); ?>" class="bg-blue-500 text-xs hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                    <i class="fa fa-print"></i> Print
                </a>
            </h2>
        </header>
        <?php if (isset($component)) { $__componentOriginala8bd0c71046a48658fc8e3324f64b484 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8bd0c71046a48658fc8e3324f64b484 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.student-details','data' => ['student' => $student]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('student-details'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['student' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($student)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8bd0c71046a48658fc8e3324f64b484)): ?>
<?php $attributes = $__attributesOriginala8bd0c71046a48658fc8e3324f64b484; ?>
<?php unset($__attributesOriginala8bd0c71046a48658fc8e3324f64b484); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8bd0c71046a48658fc8e3324f64b484)): ?>
<?php $component = $__componentOriginala8bd0c71046a48658fc8e3324f64b484; ?>
<?php unset($__componentOriginala8bd0c71046a48658fc8e3324f64b484); ?>
<?php endif; ?>
</div>
</div>
<?php /**PATH D:\laravel\college\resources\views/livewire/student-profile.blade.php ENDPATH**/ ?>