    <div class="px-4 sm:px-6 lg:px-8 py-8 w-full max-w-9xl mx-auto">
        <div
            class="flex flex-col col-span-full sm:col-span-6 bg-white dark:bg-slate-800 shadow-lg rounded-sm border border-slate-200 dark:border-slate-700">
            <header class="flex justify-between items-center px-5 py-4 border-b border-slate-100 dark:border-slate-700">
                <h2 class="font-semibold text-slate-800 dark:text-slate-100">
                    Enroll for <?php echo e($schedule->course->name); ?>(<?php echo e($schedule->year); ?> Year) | <?php echo e($schedule->academicYear->year_start->format('M Y')); ?>-<?php echo e($schedule->academicYear->year_end->format('M Y')); ?>

                </h2>
            </header>
            <div class="flex justify-between grow px-5 border-b border-slate-100 dark:border-slate-700 p-4">
               <div>
                <span class="font-bold">Submission Date:</span>
                <?php echo e($schedule->submission_from->format('d-m-Y')); ?> to <?php echo e($schedule->submission_till->format('d-m-Y')); ?>

               </div>
                <div>
                    <span class="font-bold">Late Fee From:</span>
                    <?php echo e($schedule->late_fee_starts_from->format('d-m-Y')); ?>


                </div>
            </div>

            <div class="grow px-5 border-b border-slate-100 dark:border-slate-700 p-4">
                <span class="font-bold">Core Subjects:</span>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $schedule->subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($subject->subject->name); ?><?php echo e($loop->last ? '' : ','); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
            </div>
            <div class="grow px-5 border-b border-slate-100 dark:border-slate-700 p-4">
                <div x-data="{
    selectedSubjects: <?php if ((object) ('selectedSubjects') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('selectedSubjects'->value()); ?>')<?php echo e('selectedSubjects'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('selectedSubjects'); ?>')<?php endif; ?>.defer || [],
    maxSelection: 2,
    groupSelections: {},
    toggleSubject(group, subjectId) {
        if (!this.groupSelections[group]) {
            this.groupSelections[group] = null;
        }

        if (this.groupSelections[group] === subjectId) {
            this.groupSelections[group] = null;
            this.selectedSubjects = this.selectedSubjects.filter(id => id !== subjectId);
        } else {
            if (this.selectedSubjects.length < this.maxSelection) {
                if (this.groupSelections[group]) {
                    this.selectedSubjects = this.selectedSubjects.filter(id => id !== this.groupSelections[group]);
                }
                this.groupSelections[group] = subjectId;
                this.selectedSubjects.push(subjectId);
            }
        }
    },
    isDisabled(subjectId) {
        return this.selectedSubjects.length >= this.maxSelection && !this.selectedSubjects.includes(subjectId);
    }
}">
                    <form wire:submit.prevent="submit">
                        <span class="font-bold">Elective Subjects: (Only 1 from every group with a maximum of 2)</span>
                        <div class="flex flex-col">
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $schedule->groups->groupBy('name')->sortKeys(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $groupName => $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="flex flex-col border-b-2 border-gray-200">
                                    <span class="font-semibold"><?php echo e($groupName); ?>:</span>
                                    <div>
                                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $course->course_subjects_id; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subjectId): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                    $subject = \App\Models\Subject::find($subjectId);
                                                ?>
                                                <div class="flex items-center">
                                                    <input type="checkbox"
                                                           id="subject_<?php echo e($groupName); ?>_<?php echo e($subjectId); ?>"
                                                           :class="{'bg-gray-100': isDisabled(<?php echo e($subjectId); ?>)}"
                                                           :disabled="isDisabled(<?php echo e($subjectId); ?>)"
                                                           @change="toggleSubject('<?php echo e($groupName); ?>', <?php echo e($subjectId); ?>)"
                                                           :checked="groupSelections['<?php echo e($groupName); ?>'] === <?php echo e($subjectId); ?>" />
                                                    <label for="subject_<?php echo e($groupName); ?>_<?php echo e($subjectId); ?>" class="ml-2"><?php echo e($subject->name); ?></label>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <button type="submit" class="mt-4 p-2 bg-blue-500 text-white">Send For Approval</button>

                    </form>
                </div>
            </div>
        </div>
    </div>
<?php /**PATH D:\laravel\college\resources\views/livewire/course-enrollment-form.blade.php ENDPATH**/ ?>