<div
    class="sticky flex items-center justify-between bg-white dark:bg-[#182235] border-b border-slate-200 dark:border-slate-700 z-30 p-2">
    <div class="flex">
            <span class="hidden md:block sm:block font-bold">
                &copy; <?php echo e(date('Y')); ?> - <?php echo e(config('info.app_name')); ?>

            </span>
    </div>
    <div class="flex items-center space-x-3">
        Powered by &nbsp; <i class="fa fa-bolt text-yellow-600"></i><a href="https://himsoftsolution.com"
                                                                       target="_blank"
                                                                       class="text-indigo-600 hover:text-indigo-700">Him
            Soft Solution</a>
    </div>
</div>
<?php /**PATH D:\laravel\college\resources\views/components/app/footer.blade.php ENDPATH**/ ?>