
<?php /**PATH D:\laravel\college\resources\views/components/application-logo.blade.php ENDPATH**/ ?>