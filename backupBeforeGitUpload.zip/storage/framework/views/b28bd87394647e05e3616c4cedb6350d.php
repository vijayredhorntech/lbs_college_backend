<div class="px-4 py-6 w-full">
        <div class="relative bg-primaryDark px-4 py-2 rounded-sm  border-[1px] border-primaryDark flex justify-between items-center">
                <span class="text-xl text-white/90 font-bold mb-1">
                     Education Details
                </span>

            <span
                wire:click="addForm" class=" w-max bg-white/90 rounded-[3px] text-primaryDark px-4 py-1 font-semibold text-sm border-[1px] border-white/90 hover:bg-white transition ease-in duration-2000">
                Add More
            </span>
        </div>
        <div class="p-4 bg-white">
            <form wire:submit.prevent="submitForm" class="">
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $form; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="grid lg:grid-cols-4 md:grid-cols-4 sm:grid-cols-2 grid-cols-1 gap-2">
                        <div class="w-full flex flex-col gap-1">
                            <label for="document_type_<?php echo e($index); ?>" class="font-semibold text-sm text-black">Document Type</label>
                            <select
                                id="document_type_<?php echo e($index); ?>"
                                wire:model="form.<?php echo e($index); ?>.document_name"
                                class="px-4 py-2.5 text-primaryDark placeholder-primaryDark/60 rounded-[3px] border-[1px] border-primaryDark/60 focus:ring-0 focus:outline-none focus:border-primaryDark hover:border-primaryDark">
                                <option value="">Select Document Type</option>
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $documentTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $documentType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($documentType); ?>"><?php echo e($documentType); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                            </select>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['form.'.$index.'.document_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
                        </div>

                        <div class="w-full flex flex-col gap-1">
                            <label for="document_number_<?php echo e($index); ?>" class="font-semibold text-sm text-black">Document Number</label>
                            <input placeholder="Document Number" type="text" id="document_number_<?php echo e($index); ?>" wire:model="form.<?php echo e($index); ?>.document_number" class="px-4 py-2.5 text-primaryDark placeholder-primaryDark/60 rounded-[3px] border-[1px] border-primaryDark/60 focus:ring-0 focus:outline-none focus:border-primaryDark hover:border-primaryDark">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['form.'.$index.'.document_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="w-full flex flex-col gap-1">
                            <label for="document_<?php echo e($index); ?>" class="font-semibold text-sm text-black">Document</label>
                            <input placeholder="Upload File" type="file" id="document_<?php echo e($index); ?>" wire:model="form.<?php echo e($index); ?>.document" class="px-4 py-2 text-primaryDark placeholder-primaryDark/60 rounded-[3px] border-[1px] border-primaryDark/60 focus:ring-0 focus:outline-none focus:border-primaryDark hover:border-primaryDark">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['form.'.$index.'.document'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="mb-4 flex items-end">
                            <button type="button" wire:click="removeForm(<?php echo e($index); ?>)" class="w-max bg-red/90 rounded-[3px] text-white px-4 py-1 font-semibold text-sm border-[1px] border-red/90 hover:bg-red transition ease-in duration-2000">
                                Remove
                            </button>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                <div class="mt-4 flex w-full justify-end">
                    <button type="submit" class="w-max bg-primaryDark/80 rounded-[3px] text-white px-4 py-1.5 font-semibold text-md border-[1px] border-primaryDark hover:bg-primaryDark transition ease-in duration-2000">
                        Save
                    </button>
                </div>
            </form>

        </div>
    </div>



<?php /**PATH /home/vinumuum/lbsattendance.himsoft.online/resources/views/livewire/student-documents.blade.php ENDPATH**/ ?>