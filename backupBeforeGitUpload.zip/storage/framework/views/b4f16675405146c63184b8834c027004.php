<!-- resources/views/livewire/mark-attendance.blade.php -->
  <div class="w-full py-12">

      <div class="lg:w-[70%] md:w-[80%] w-full mx-auto bg-white rounded-md p-4 shadow-lg shadow-gray-400/60">
        <!-- Top section for class details and date selection -->
        <div class="w-full flex flex-wrap gap-4 bg-gray-200 px-4 py-2 rounded-sm">
        <span class="font-semibold text-gray-600 text-md  border-r-[1px] border-gray-500 pr-2">Subject Name:
            <span class="font-normal text-green-600 "><?php echo e($facultyClass->subject->name); ?></span>
        </span>
            <span class="font-semibold text-gray-600 text-md border-r-[1px] border-gray-500 pr-2">Faculty Name:
            <span class="font-normal text-green-600 "><?php echo e($facultyClass->faculty->name); ?></span>
        </span>
            <span class="font-semibold text-gray-600 text-md border-r-[1px] border-gray-500 pr-2">Time:
            <span class="font-normal text-green-600 "><?php echo e(now()->format('h:i A')); ?></span>

        </span>
            <form wire:submit.prevent="">
                <span class="font-semibold text-gray-600 text-md ">Date:
                    <input type="date" wire:model="attendanceDate" class="ml-2 border border-gray-300 rounded px-2 py-1 text-sm text-green-600" />
                </span>
                <button wire:click="fetchStudents()" class="px-4 py-2 bg-green-600 text-white font-semibold rounded hover:bg-green-700 transition">Search</button>
            </form>

        </div>

          <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6 p-6">
              <!-- Students Card -->
              <div class="bg-gradient-to-r from-blue-500 to-teal-500 p-6 rounded-lg shadow-lg flex items-center justify-between text-white">
                  <div>
                      <div class="text-xs font-semibold uppercase tracking-wider">Students</div>
                      <div class="text-3xl font-bold"><?php echo e(count($students)); ?></div>
                  </div>
                  <div class="w-16 h-16 bg-white rounded-full flex items-center justify-center">
                      <svg xmlns="http://www.w3.org/2000/svg" class="w-8 h-8 text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.403-2.805A6.978 6.978 0 0018 12c0-3.866-3.134-7-7-7s-7 3.134-7 7c0 1.496.506 2.87 1.403 3.895L4 17h5M10 13v-2m4 2v-2m-2 2V9m-2 2V9m-1 1h2M6 13h2m4 0h2m4 0h2" />
                      </svg>
                  </div>
              </div>

              <!-- Faculty Card -->
              <div class="bg-gradient-to-r from-green-500 to-yellow-500 p-6 rounded-lg shadow-lg flex items-center justify-between text-white">
                  <div>
                      <div class="text-xs font-semibold uppercase tracking-wider">Present</div>
                      <div class="text-3xl font-bold"><?php echo e($presentCount); ?></div>
                  </div>
                  <div class="w-16 h-16 bg-white rounded-full flex items-center justify-center">
                      <svg xmlns="http://www.w3.org/2000/svg" class="w-8 h-8 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 2a7 7 0 00-7 7v1.38C5.306 10.865 6 11.861 6 13c0 2.236-1.176 4.079-3 5.22m18-7.102V9a7 7 0 00-7-7M5 17v4a2 2 0 002 2h10a2 2 0 002-2v-4m-7 0V7m0 0h4m-4 0H9" />
                      </svg>
                  </div>
              </div>

              <!-- Courses Card -->
              <div class="bg-gradient-to-r from-purple-500 to-pink-500 p-6 rounded-lg shadow-lg flex items-center justify-between text-white">
                  <div>
                      <div class="text-xs font-semibold uppercase tracking-wider">Absent</div>
                      <div class="text-3xl font-bold"><?php echo e($absentCount); ?></div>
                  </div>
                  <div class="w-16 h-16 bg-white rounded-full flex items-center justify-center">
                      <svg xmlns="http://www.w3.org/2000/svg" class="w-8 h-8 text-purple-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 7V3m0 0l-4 4m4-4l4 4m-4 4v8m-4-8v8M5 9h14m-7-7v14m-3-4h12" />
                      </svg>
                  </div>
              </div>

          </div>


          <!-- Bulk actions -->
        <div class="w-full flex justify-end lg:flex-row md:flex-row sm:flex-row flex-col lg:gap-4 md:gap-4 sm:gap-4 gap-2 mt-4">
            <button wire:click="markAllExceptSelected('Present')" class="px-4 py-2 bg-green-600 text-white font-semibold rounded hover:bg-green-700 transition">Mark All Present Except Selected</button>
            <button wire:click="markSelected('Present')" class="px-4 py-2 bg-blue-600 text-white font-semibold rounded hover:bg-blue-700 transition">Mark Selected as Present</button>
            <button wire:click="markSelected('Absent')" class="px-4 py-2 bg-red-600 text-white font-semibold rounded hover:bg-red-700 transition">Mark Selected as Absent</button>
        </div>

        <!-- Attendance table -->
        <table class="table border-[1px] border-gray-300 border-collapse w-full mt-4">
            <tr>
                <th class="border-[1px] border-gray-300 text-left px-4 py-2 text-[#6366f1] text-[15px] font-semibold">#</th>
                <th class="border-[1px] border-gray-300 text-left px-4 py-2 text-[#6366f1] text-[15px] font-semibold">Student</th>
                <th class="border-[1px] border-gray-300 text-left px-4 py-2 text-[#6366f1] text-[15px] font-semibold">Attendance</th>
            </tr>
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="border-[1px] border-gray-300 text-left px-4 py-2 text-gray-600 text-sm">
                        <input type="checkbox" wire:model="selectedStudents" value="<?php echo e($student->id); ?>">
                    </td>
                    <td class="border-[1px] border-gray-300 text-left px-4 py-2 text-gray-600 text-sm"><?php echo e($student->full_name); ?></td>
                    <td class="border-[1px] border-gray-300 text-left px-4 py-2 text-<?php echo e($attendance[$student->id] === 'Present' ? 'green' : 'red'); ?>-600 text-sm font-semibold flex flex-col gap-2">
                        <?php echo e($attendance[$student->id]); ?>

                           <div class="flex gap-2">
                               <button wire:click="markAttendance(<?php echo e($student->id); ?>, 'Present')" class="px-2 py-0.5 rounded-full text-sm bg-green-600 text-white font-semibold border-[1px] border-green-600 hover:bg-white hover:text-green-600 transition ease-in duration-200">
                                   <i class="fa fa-check"></i>
                               </button>
                               <button wire:click="markAttendance(<?php echo e($student->id); ?>, 'Absent')" class="px-2 py-0.5 rounded-full text-sm bg-red-600 text-white font-semibold border-[1px] border-red-600 hover:bg-white hover:text-red-600 transition ease-in duration-200">
                                   <i class="fa fa-xmark"></i>
                               </button>
                           </div>
                    </td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
        </table>
    </div>
</div>
<?php /**PATH D:\laravel\college\resources\views/livewire/mark-attendance.blade.php ENDPATH**/ ?>