<div class="w-full p-4">
    <form wire:submit.prevent="save" class="w-full p-4 bg-white rounded-md shadow-lg shadow-gray-400/50">
        <!--[if BLOCK]><![endif]--><?php if($isEditMode): ?>
            <input type="hidden" wire:model="facultyClassId">
        <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->

       <div class="w-full grid lg:grid-cols-3 md:grid-cols-4 sm:grid-cols-2 grid-cols-1 gap-4">
           <div class="w-full">
               <label for="faculty" class="block text-sm font-semibold text-gray-600">Faculty</label>
               <select id="faculty" wire:model="facultyId" class="form-select mt-1 block w-full" wire:change="updateSubjects()">
                   <option value="">Select Faculty</option>
                   <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $faculties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faculty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <option value="<?php echo e($faculty->id); ?>"><?php echo e($faculty->name); ?></option>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
               </select>
               <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['facultyId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
           </div>

           <div class="w-full">
               <label for="subject" class="block text-sm font-semibold text-gray-600">Subject</label>
               <select id="subject" wire:model="subjectId" class="form-select mt-1 block w-full">
                   <option value="">Select Subject</option>
                   <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <option value="<?php echo e($subject->id); ?>"><?php echo e($subject->name); ?></option>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
               </select>
               <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['subjectId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
           </div>

           <div class="w-full">
               <label for="classTimeStart" class="block text-sm font-semibold text-gray-600">Class Time Start</label>
               <input id="classTimeStart" type="time" wire:model="classTimeStart" class="form-input mt-1 block w-full">
               <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['classTimeStart'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
           </div>

           <div class="w-full">
               <label for="classTimeEnd" class="block text-sm font-semibold text-gray-600">Class Time End</label>
               <input id="classTimeEnd" type="time" wire:model="classTimeEnd" class="form-input mt-1 block w-full">
               <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['classTimeEnd'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
           </div>

           <div class="w-full">
               <label for="classDays" class="block text-sm font-semibold text-gray-600">Class Days</label>
               <select id="classDays" wire:model="classDays" multiple class="form-select mt-1 block w-full">
                   <option value="Monday">Monday</option>
                   <option value="Tuesday">Tuesday</option>
                   <option value="Wednesday">Wednesday</option>
                   <option value="Thursday">Thursday</option>
                   <option value="Friday">Friday</option>
                   <option value="Saturday">Saturday</option>
                   <option value="Sunday">Sunday</option>
               </select>
               <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['classDays'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
           </div>

           <div class="w-full flex items-end">

               <button type="submit" class="px-4 py-1.5 rounded-sm text-sm bg-green-600 text-white font-semibold border-[1px] border-green-600 hover:bg-white hover:text-green-600 transition ease-in duration-2000"><?php echo e($isEditMode ? 'Update Class' : 'Create Class'); ?></button>
           </div>
       </div>

    </form>




</div>
<?php /**PATH D:\laravel\college\resources\views/livewire/faculty-class-form.blade.php ENDPATH**/ ?>