<div>
    <div class="px-4 sm:px-6 lg:px-8 py-8 w-full max-w-9xl mx-auto">
        <div
            class="flex flex-col col-span-full sm:col-span-6 bg-white dark:bg-slate-800 shadow-lg rounded-sm border border-slate-200 dark:border-slate-700">
            <header class="px-5 py-4 border-b border-slate-100 dark:border-slate-700">
                <h2 class="font-semibold text-slate-800 dark:text-slate-100">
                    Fee Structure
                </h2>
            </header>
            <div class="container mx-auto p-4">
                <?php
                    $groupedFeeStructures = $feeStructures->groupBy('category');
                ?>

                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $groupedFeeStructures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category => $fees): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="mb-6">
                        <h2 class="text-xl font-bold"><?php echo e($category); ?></h2>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $fees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div
                                class="grid grid-cols-2 items-center mb-2 <?php echo e($loop->iteration % 2 == 0 ? 'bg-gray-200' : 'bg-gray-300'); ?> rounded-md p-4">
                                <span><?php echo e($fee->fund_name); ?></span>
                                <div class="w-full flex items-center">
                                    <input
                                        type="number" placeholder="<?php echo e($fee->fund_name); ?>"
                                        class="border rounded px-2 py-1 text-black"
                                        wire:model.defer="feeModel.<?php echo e($fee->id); ?>"
                                        value="<?php echo e($feeModel[$fee->id] ?? $fee->amount); ?>"
                                    />
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->

                <!--[if BLOCK]><![endif]--><?php if($feeModel): ?>
                    <button
                        class="w-full bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded" wire:loading.attr="disabled"
                        wire:click="save"
                    >
                        Save
                    </button>
                <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
            </div>

        </div>
    </div>
</div>
<?php /**PATH D:\laravel\college\resources\views/livewire/fee-structure.blade.php ENDPATH**/ ?>